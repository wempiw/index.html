document.addEventListener('DOMContentLoaded', () => {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            menuToggle.classList.toggle('active');
        });

        // Close menu when a link is clicked
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('active')) {
                    navLinks.classList.remove('active');
                    menuToggle.classList.remove('active');
                }
            });
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const hrefAttribute = this.getAttribute('href');
            if (hrefAttribute && hrefAttribute !== "#" && document.querySelector(hrefAttribute)) {
                e.preventDefault();
                document.querySelector(hrefAttribute).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Active navigation link highlighting on scroll
    const sections = document.querySelectorAll('section[id]');
    const navLi = document.querySelectorAll('header nav ul li a');
    const headerHeight = document.querySelector('header')?.offsetHeight || 70;
    
    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (pageYOffset >= (sectionTop - headerHeight * 1.5)) { // Adjust offset for better accuracy
                current = section.getAttribute('id');
            }
        });

        navLi.forEach(a => {
            a.classList.remove('active');
            if (a.getAttribute('href').substring(1) === current) {
                a.classList.add('active');
            }
        });
        
        // Ensure home is active when at the very top
        if (window.pageYOffset < sections[0].offsetTop - headerHeight * 1.5 ) { 
             navLi.forEach(a => a.classList.remove('active'));
             const homeLink = document.querySelector('header nav ul li a[href="#hero"]');
             if(homeLink) homeLink.classList.add('active');
        }
    });

    // Add subtle scroll animations
    const animatedElements = document.querySelectorAll('.service-card, .about-content > div, .financial-log-content > div');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        observer.observe(el);
    });

    // Contact Form Submission
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('form-message');

    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();

            if (!name || !email || !subject || !message) {
                displayFormMessage('Harap isi semua kolom yang wajib diisi.', 'error', formMessage);
                return;
            }
            if (!validateEmail(email)) {
                displayFormMessage('Format email tidak valid.', 'error', formMessage);
                return;
            }
            console.log('Form Submitted:', { name, email, subject, message });
            displayFormMessage('Pesan Anda telah berhasil dikirim. Kami akan segera menghubungi Anda.', 'success', formMessage);
            contactForm.reset();
            setTimeout(() => { if(formMessage) formMessage.style.display = 'none'; }, 5000);
        });
    }

    function displayFormMessage(message, type, element) {
        if (element) {
            element.textContent = message;
            element.className = `form-message ${type}`;
            element.style.display = 'block';
        }
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }

    // --- Financial Log Functionality ---
    const transactionForm = document.getElementById('transactionForm');
    const transactionsList = document.getElementById('transactionsList');
    const totalIncomeEl = document.getElementById('totalIncome');
    const totalExpenseEl = document.getElementById('totalExpense');
    const currentBalanceEl = document.getElementById('currentBalance');
    const filterTypeEl = document.getElementById('filterType');
    const filterMonthEl = document.getElementById('filterMonth');
    const filterYearEl = document.getElementById('filterYear');
    const clearAllDataButton = document.getElementById('clearAllDataButton');
    const financialSummaryChartCtx = document.getElementById('financialSummaryChart')?.getContext('2d');
    let financialSummaryChartInstance = null;

    // --- Family Members Functionality ---
    const addFamilyMemberForm = document.getElementById('addFamilyMemberForm');
    const memberNameInput = document.getElementById('memberName');
    const familyMembersListEl = document.getElementById('familyMembersList');
    const noFamilyMembersMessage = document.getElementById('noFamilyMembersMessage');

    let transactions = JSON.parse(localStorage.getItem('transactions')) || [];
    let familyMembers = JSON.parse(localStorage.getItem('familyMembers')) || [];

    function saveTransactions() {
        localStorage.setItem('transactions', JSON.stringify(transactions));
    }

    function saveFamilyMembers() {
        localStorage.setItem('familyMembers', JSON.stringify(familyMembers));
    }

    function formatCurrency(amount) {
        return `Rp ${Number(amount).toLocaleString('id-ID')}`;
    }
    
    function populateFilterDropdowns() {
        const months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
        const uniqueYears = [...new Set(transactions.map(t => new Date(t.date).getFullYear()))].sort((a, b) => b - a);
        const uniqueMonthsInYears = {}; // {2023: [0, 1, ...], 2024: [5,6,...]}

        transactions.forEach(t => {
            const date = new Date(t.date);
            const year = date.getFullYear();
            const month = date.getMonth();
            if (!uniqueMonthsInYears[year]) {
                uniqueMonthsInYears[year] = new Set();
            }
            uniqueMonthsInYears[year].add(month);
        });

        filterMonthEl.innerHTML = '<option value="all">Semua Bulan</option>';
        // For simplicity, populate all months for now. Can be refined to show only months with data.
        months.forEach((month, index) => {
            const option = document.createElement('option');
            option.value = index; // 0 for January, 1 for February, etc.
            option.textContent = month;
            filterMonthEl.appendChild(option);
        });
        
        filterYearEl.innerHTML = '<option value="all">Semua Tahun</option>';
        uniqueYears.forEach(year => {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            filterYearEl.appendChild(option);
        });
    }


    function renderTransactions() {
        transactionsList.innerHTML = ''; // Clear existing list

        const typeFilter = filterTypeEl.value;
        const monthFilter = filterMonthEl.value;
        const yearFilter = filterYearEl.value;

        let filteredTransactions = transactions.filter(t => {
            const transactionDate = new Date(t.date);
            const typeMatch = typeFilter === 'all' || t.type === typeFilter;
            const monthMatch = monthFilter === 'all' || transactionDate.getMonth() == monthFilter;
            const yearMatch = yearFilter === 'all' || transactionDate.getFullYear() == yearFilter;
            return typeMatch && monthMatch && yearMatch;
        });

        // Sort by date, newest first
        filteredTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));

        if (filteredTransactions.length === 0) {
            transactionsList.innerHTML = '<tr><td colspan="5" class="no-transactions">Tidak ada transaksi yang sesuai dengan filter.</td></tr>';
        } else {
            filteredTransactions.forEach(transaction => {
                const row = transactionsList.insertRow();
                row.classList.add(transaction.type); // For styling income/expense rows

                row.insertCell().textContent = new Date(transaction.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
                row.insertCell().textContent = transaction.type === 'income' ? 'Pemasukan' : 'Pengeluaran';
                row.insertCell().textContent = transaction.description;
                row.insertCell().textContent = formatCurrency(transaction.amount);
                
                const actionsCell = row.insertCell();
                const deleteBtn = document.createElement('button');
                deleteBtn.classList.add('delete-transaction-btn');
                deleteBtn.innerHTML = '<i class="fas fa-trash-alt"></i>';
                deleteBtn.setAttribute('aria-label', 'Hapus transaksi');
                deleteBtn.onclick = () => deleteTransaction(transaction.id);
                actionsCell.appendChild(deleteBtn);
            });
        }
        updateSummary(filteredTransactions); // Update summary based on filtered transactions
        updateFinancialSummaryChart(filteredTransactions); // Update chart with filtered data
        if(transactions.length > 0 && (filterYearEl.options.length <=1 || filterMonthEl.options.length <= 12)) {
           populateFilterDropdowns(); // Re-populate if new years/months appear from new transactions
        }
    }

    function updateSummary(currentTransactions) { // Takes an array of transactions (filtered or all)
        const income = currentTransactions
            .filter(t => t.type === 'income')
            .reduce((sum, t) => sum + t.amount, 0);
        
        const expense = currentTransactions
            .filter(t => t.type === 'expense')
            .reduce((sum, t) => sum + t.amount, 0);
        
        const balance = income - expense;

        totalIncomeEl.textContent = formatCurrency(income);
        totalExpenseEl.textContent = formatCurrency(expense);
        currentBalanceEl.textContent = formatCurrency(balance);
    }

    function updateFinancialSummaryChart(transactionsToDisplay) {
        if (!financialSummaryChartCtx) return;

        const income = transactionsToDisplay
            .filter(t => t.type === 'income')
            .reduce((sum, t) => sum + t.amount, 0);
        
        const expense = transactionsToDisplay
            .filter(t => t.type === 'expense')
            .reduce((sum, t) => sum + t.amount, 0);

        const chartData = {
            labels: ['Pemasukan', 'Pengeluaran'],
            datasets: [{
                label: 'Ringkasan Keuangan',
                data: [income, expense],
                backgroundColor: [
                    'rgba(44, 165, 141, 0.7)', // --accent-color with alpha
                    'rgba(220, 53, 69, 0.7)'  // --danger-color with alpha
                ],
                borderColor: [
                    'rgb(44, 165, 141)',
                    'rgb(220, 53, 69)'
                ],
                borderWidth: 1
            }]
        };

        const chartConfig = {
            type: 'bar',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return formatCurrency(value).replace('Rp ', ''); // Remove Rp for cleaner axis
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false // Or true if you want to show the legend
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += formatCurrency(context.parsed.y);
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        };

        if (financialSummaryChartInstance) {
            financialSummaryChartInstance.destroy();
        }
        financialSummaryChartInstance = new Chart(financialSummaryChartCtx, chartConfig);
    }

    function addTransaction(e) {
        e.preventDefault();
        const date = document.getElementById('transactionDate').value;
        const type = document.getElementById('transactionType').value;
        const description = document.getElementById('transactionDescription').value.trim();
        const amount = parseFloat(document.getElementById('transactionAmount').value);

        if (!date || !description || isNaN(amount) || amount <= 0) {
            alert('Mohon isi semua field dengan benar. Jumlah harus angka positif.');
            return;
        }

        const newTransaction = {
            id: Date.now(), // Simple unique ID
            date,
            type,
            description,
            amount
        };

        transactions.push(newTransaction);
        saveTransactions();
        renderTransactions();
        transactionForm.reset();
        document.getElementById('transactionDate').valueAsDate = new Date(); // Set default date to today
    }

    function deleteTransaction(id) {
        if (confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) {
            transactions = transactions.filter(t => t.id !== id);
            saveTransactions();
            renderTransactions();
            populateFilterDropdowns(); // Repopulate in case a year/month becomes empty
        }
    }
    
    function clearAllTransactions() {
        if (confirm('PERHATIAN! Ini akan menghapus SEMUA data transaksi Anda. Aksi ini tidak dapat diurungkan. Lanjutkan?')) {
            transactions = [];
            saveTransactions();
            renderTransactions();
            populateFilterDropdowns(); // Reset dropdowns
            alert('Semua data transaksi telah dihapus.');
        }
    }

    // --- Family Member Functions ---
    function renderFamilyMembers() {
        familyMembersListEl.innerHTML = ''; // Clear existing list

        if (familyMembers.length === 0) {
            noFamilyMembersMessage.style.display = 'block';
            familyMembersListEl.style.display = 'none';
        } else {
            noFamilyMembersMessage.style.display = 'none';
            familyMembersListEl.style.display = 'block';
            familyMembers.forEach(member => {
                const li = document.createElement('li');
                li.setAttribute('data-id', member.id);

                const nameSpan = document.createElement('span');
                nameSpan.classList.add('member-name');
                nameSpan.textContent = member.name;

                const contributionDiv = document.createElement('div');
                contributionDiv.classList.add('contribution-status');
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.id = `contrib-${member.id}`;
                checkbox.checked = member.contributed;
                checkbox.addEventListener('change', () => toggleContributionStatus(member.id));
                
                const label = document.createElement('label');
                label.setAttribute('for', `contrib-${member.id}`);
                label.textContent = 'Kontribusi'; // Simple label

                contributionDiv.appendChild(checkbox);
                contributionDiv.appendChild(label);

                const deleteBtn = document.createElement('button');
                deleteBtn.classList.add('delete-member-btn');
                deleteBtn.innerHTML = '<i class="fas fa-user-times"></i>'; // Icon for delete
                deleteBtn.setAttribute('aria-label', `Hapus ${member.name}`);
                deleteBtn.addEventListener('click', () => deleteFamilyMember(member.id));

                li.appendChild(nameSpan);
                li.appendChild(contributionDiv);
                li.appendChild(deleteBtn);
                familyMembersListEl.appendChild(li);
            });
        }
    }

    function addFamilyMember(e) {
        e.preventDefault();
        const name = memberNameInput.value.trim();
        if (!name) {
            alert('Nama anggota keluarga tidak boleh kosong.');
            return;
        }

        const newMember = {
            id: Date.now(),
            name: name,
            contributed: false
        };
        familyMembers.push(newMember);
        saveFamilyMembers();
        renderFamilyMembers();
        addFamilyMemberForm.reset();
    }

    function deleteFamilyMember(id) {
        if (confirm('Apakah Anda yakin ingin menghapus anggota keluarga ini?')) {
            familyMembers = familyMembers.filter(member => member.id !== id);
            saveFamilyMembers();
            renderFamilyMembers();
        }
    }

    function toggleContributionStatus(id) {
        const member = familyMembers.find(member => member.id === id);
        if (member) {
            member.contributed = !member.contributed;
            saveFamilyMembers();
            // No need to call renderFamilyMembers() here as the checkbox state is directly managed
            // However, if other visual cues depend on this, then re-render.
            // For now, direct checkbox manipulation is fine.
        }
    }

    // Event Listeners
    if (transactionForm) {
        transactionForm.addEventListener('submit', addTransaction);
        document.getElementById('transactionDate').valueAsDate = new Date(); // Set default date to today
    }
    if (filterTypeEl) filterTypeEl.addEventListener('change', renderTransactions);
    if (filterMonthEl) filterMonthEl.addEventListener('change', renderTransactions);
    if (filterYearEl) filterYearEl.addEventListener('change', renderTransactions);
    if (clearAllDataButton) clearAllDataButton.addEventListener('click', clearAllTransactions);

    if (addFamilyMemberForm) {
        addFamilyMemberForm.addEventListener('submit', addFamilyMember);
    }

    // Initial render
    populateFilterDropdowns();
    renderTransactions(); 
    renderFamilyMembers(); // Initial render for family members
});